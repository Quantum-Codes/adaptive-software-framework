# Feature Tagging

Instructions for scanning the codebase and assigning unique "Feature IDs" to code blocks.
