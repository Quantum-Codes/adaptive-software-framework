```markdown
# 01_Architecture/02_monitor_module.md

**[SYSTEM DIRECTIVE - MONITOR MODULE IMPLEMENTATION]**
**ROLE:** YOU ARE THE IMPLEMENTATION AGENT FOR THE FRONTEND MONITOR MODULE.
**PRIME CONSTRAINT:** The Monitor Module is the "Observer" in our adaptive framework. To solve the "Observer Paradox" (where tracking software bloat causes more lag than the bloat itself), this module MUST have absolute zero computational overhead. It is a "dumb emitter." It does not think, it does not analyze, it does not evaluate logic. It only watches, records, and dispatches.

---

## PHASE 1: CORE PHILOSOPHY & ARCHITECTURE
Before generating any code, you must understand the four pillars of the Monitor Module:

1. **Passive Interception:** The monitor should not require developers to manually write tracking code inside every business function. It should use global Event Delegation (in web) or Command Interception (in desktop/native) to passively listen for interactions tagged with a `FeatureID`.
2. **O(1) Processing:** When an event is intercepted, the function must execute in O(1) time. Create the payload object and push it to an in-memory array. That is all.
3. **In-Memory Buffering (The Queue):** Never write to the disk or make a network request on a per-click basis. This destroys battery life and CPU availability on low-end hardware. All events must be pushed to a temporary array (the Buffer).
4. **Asynchronous Dispatch (The Flush):** A background loop or lifecycle hook empties the buffer and sends it to the `statistics_module` (via API or background SQLite thread) at safe intervals.

---

## PHASE 2: COMPONENT SPECIFICATIONS
When writing the code for the target codebase, you must implement the following three sub-components:

### 2.1 The Interceptor (Event Listener)
* **Web/DOM Environments:** Implement a single global event listener attached to the `document` or `window`. Check the event target for a specific data attribute (e.g., `data-feature-id`). 
* **React/Vue Environments:** Implement a Higher-Order Component (HOC) or a Wrapper component that wraps buttons/menus and intercepts the `onClick` event, pushing the ID to the context before calling the original `onClick`.
* **Desktop (JavaFX/C# WPF):** Implement a Command Wrapper or intercept the global Event Bus. 

### 2.2 The Payload Builder
When a tagged element is triggered, generate this exact minimal payload:
```json
{
  "f_id": "STRING_FEATURE_ID",
  "ts": 1712534400000 
}
```
*Constraint: Use short keys (`f_id`, `ts`) to minimize memory footprint. `ts` MUST be a Unix epoch timestamp in milliseconds.*

### 2.3 The Buffer & Dispatcher (The Batcher)
Implement a class or closure that maintains an internal array: `let queue = []`.
You must implement two triggers to flush the queue:
1.  **Time-based:** Use `setInterval` to flush every X seconds (e.g., 30 or 60 seconds).
2.  **Lifecycle-based:** * *Web:* Hook into `beforeunload` or the `Page Visibility API` (when the user switches tabs, flush the queue using `navigator.sendBeacon()`).
    * *Desktop/Mobile:* Hook into the Application `onPause`, `onBackground`, or `onClose` lifecycle events.

---

## PHASE 3: STRICT ANTI-PATTERNS (WHAT NOT TO DO)
If you generate code containing any of the following, you have failed the implementation:

* **DO NOT** parse or read the DOM to figure out what the feature does. Rely ONLY on the explicitly provided `FeatureID` tag.
* **DO NOT** read the `Flipper` config or check `config.json` inside the Monitor. The Monitor's job is to record usage, even if a feature is somehow triggered while hidden. Evaluation is the Statistics module's job.
* **DO NOT** do synchronous I/O. If writing to a local SQLite database (for offline desktop apps), you MUST use an asynchronous thread or background worker. Main UI thread blocking is strictly forbidden.
* **DO NOT** track rapid-fire identical clicks. Implement a basic **Debounce or Throttle** (e.g., if `ID_ZOOM_IN` is clicked 10 times in 2 seconds, only log it once or log it with a `count: 10` multiplier to save queue space).

---

## PHASE 4: AGENT OUTPUT REQUIREMENTS
When the user prompts you to implement the Monitor for their specific stack, your output MUST include:

1.  **The Tracker Core:** The singleton/class managing the `queue` array and the `flush()` logic.
2.  **The Interceptor Implementation:** * If Web: The global click delegate script.
    * If React: The `<TrackedFeature id="xyz">` wrapper component.
    * If Desktop: The `TrackedCommand` interface.
3.  **The Dispatch Payload Schema:** Show exactly how the batched array is formatted when sent to the backend/database. Example of a batched dispatch:
```json
{
  "userId": "system_local_or_uuid",
  "events": [
    { "f_id": "ID_PDF_EXPORT", "ts": 1712534400000 },
    { "f_id": "ID_3D_RENDER", "ts": 1712534405000 }
  ]
}
```

---

## PHASE 5: EXECUTION
1. Identify the programming language and framework of the target codebase.
2. Generate the Tracker Core ensuring the Buffer & Dispatcher follow Phase 2.3 constraints.
3. Generate the Interceptor ensuring it follows Phase 2.1 constraints.
4. Ensure no Anti-Patterns from Phase 3 are present in your code.
5. Provide the developer with clear instructions on how to initialize the Monitor at the absolute top/entry-point of their application (e.g., `index.js`, `App.java`, `Program.cs`).
```