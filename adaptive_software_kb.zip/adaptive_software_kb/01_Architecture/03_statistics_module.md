```markdown
# 01_Architecture/03_statistics_module.md

**[SYSTEM DIRECTIVE - STATISTICS MODULE IMPLEMENTATION]**
**ROLE:** YOU ARE THE IMPLEMENTATION AGENT FOR THE BACKEND STATISTICS MODULE.
**PRIME CONSTRAINT:** The Statistics Module is the "Data Processor" of our adaptive framework. To maintain absolute performance and solve the "Observer Paradox," this module MUST be strictly decoupled. Tracking data reception must be instantaneous (O(1)), and the heavy lifting of evaluating those statistics (The "Flip") MUST occur asynchronously via background workers or cron jobs. Never block a user's web request to calculate their adaptive UI state.

---

## PHASE 1: CORE PHILOSOPHY & ARCHITECTURE
Before generating any backend or database code, you must understand the architectural separation of concerns within this module:

1. **Fire-and-Forget Ingestion:** When the frontend Monitor Module sends a batch of tracking data, the backend endpoint must acknowledge the payload immediately (HTTP 202 Accepted) and hand the data to a background queue or perform a fast, atomic DB write. 
2. **Atomic Increments:** Avoid read-modify-write cycles. Use database-native atomic increments (e.g., `UPDATE ... SET count = count + 1` in SQL, or `$inc` in MongoDB) to prevent race conditions when multiple tabs or devices send data simultaneously.
3. **Time-Bucketing (Recency Tracking):** A lifetime count of "100 uses" is useless if 99 of those were from 3 years ago. You MUST implement time-bucketing. Store usage counts tied to a specific time window (e.g., a specific Day or Week) so the Evaluation Engine can filter for "usage in the last 14 days."
4. **The Asynchronous Evaluator:** The logic that decides whether a feature should be hidden MUST NOT run when tracking data is received. It runs purely on a scheduled basis (e.g., a weekly cron job or at user login).

---

## PHASE 2: DATABASE SCHEMA DESIGN
You must generate a schema tailored to the user's stack (SQL, NoSQL, or local SQLite for offline apps). 

### 2.1 The Time-Bucketed Stats Table
The database must support efficient querying of user feature usage over time. 

**SQL Example (PostgreSQL/SQLite):**
```sql
CREATE TABLE feature_usage_stats (
    user_id VARCHAR(255) NOT NULL,
    feature_id VARCHAR(100) NOT NULL,
    time_bucket DATE NOT NULL, -- e.g., '2026-04-14'
    usage_count INT DEFAULT 1,
    PRIMARY KEY (user_id, feature_id, time_bucket)
);
```

**MongoDB Example:**
```json
{
  "user_id": "uuid",
  "feature_id": "ID_3D_RENDER",
  "time_bucket": ISODate("2026-04-14T00:00:00Z"),
  "usage_count": 5
}
```

---

## PHASE 3: THE INGESTION ENDPOINT (THE RECEIVER)
You must generate a highly optimized API endpoint to receive the batched payload from the Monitor Module.

### Requirements for the Endpoint:
1. **Route:** Usually a `POST /api/adaptive/track`.
2. **Payload Validation:** Validate the payload array (e.g., `[{f_id: "ID_X", ts: 123}, ...]`).
3. **Upsert Logic:** The database command must "Insert if not exists, Increment if exists."
   * *PostgreSQL:* `INSERT INTO ... ON CONFLICT (user_id, feature_id, time_bucket) DO UPDATE SET usage_count = feature_usage_stats.usage_count + 1`
   * *MongoDB:* `db.collection.updateOne({ ... }, { $inc: { usage_count: 1 } }, { upsert: true })`
4. **Offline Desktop Apps:** If generating code for a local app (Java/C#), this "endpoint" is an asynchronous background worker thread writing to the local SQLite file.

---

## PHASE 4: THE EVALUATION ENGINE (THE "WEEKLY FLIP")
This is the core logic that actually adapts the software. It bridges the `statistics_module` and the `metadata_schema`.

### Requirements for the Evaluator:
1. **Trigger Mechanism:** Implement a trigger. This should be a Cron Job (e.g., runs Sunday at 2 AM) OR an asynchronous check executed right after a user authenticates/logs in.
2. **The Aggregation Query:** Generate a query to calculate the sum of usage over the target window.
   * *Logic:* "Sum `usage_count` where `user_id = X` and `time_bucket >= (NOW - 14 Days)`."
3. **Threshold Assessment:** Compare the aggregated sum against a predefined configuration (e.g., `MINIMUM_UTILITY_THRESHOLD = 3`).
4. **Config Mutation:** If a `Feature_ID` falls below the threshold, update the user's `metadata_schema` (the Flipper config) to set `"isEnabled": false`.

### Pseudocode Logic Flow for the Evaluator:
```python
def run_adaptation_cycle(user_id):
    cutoff_date = datetime.now() - timedelta(days=14)
    
    # 1. Get recent usage stats
    recent_stats = db.query(
        "SELECT feature_id, SUM(usage_count) as total FROM stats WHERE user_id = ? AND time_bucket >= ? GROUP BY feature_id", 
        user_id, cutoff_date
    )
    
    # 2. Load current user Flipper config
    user_config = load_metadata_schema(user_id)
    
    # 3. Evaluate and Flip
    for feature in ALL_ADAPTIVE_FEATURES:
        total_uses = recent_stats.get(feature.id, 0)
        
        if total_uses < feature.threshold:
            user_config.features[feature.id] = False # Hide it
        else:
            user_config.features[feature.id] = True  # Keep/Restore it
            
    # 4. Save new Flipper config
    save_metadata_schema(user_id, user_config)
```

---

## PHASE 5: STRICT ANTI-PATTERNS (WHAT NOT TO DO)
If you generate code containing any of the following, you have failed the implementation:

* **DO NOT** perform the "Evaluation Engine" logic inside the "Ingestion Endpoint." The tracking endpoint must NEVER calculate thresholds or update the Flipper config. It only increments counts.
* **DO NOT** use complex ORM relationships or deep table joins for the usage tracking table. It must remain a flat, highly indexed table for maximum write speed.
* **DO NOT** delete records arbitrarily. Instead, implement a separate cleanup job that drops `time_bucket` rows older than 60 days to prevent infinite database growth.
* **DO NOT** build a real-time WebSocket connection for usage tracking. HTTP POST batching or background SQLite threads are mandatory to preserve battery/CPU.

---

## PHASE 6: AGENT OUTPUT REQUIREMENTS
When the user prompts you to implement the Statistics Module, your output MUST include:

1. **The Database Schema/Migrations:** Explicit SQL or NoSQL definitions for the time-bucketed stats table, including necessary composite primary keys or indexes.
2. **The Ingestion Controller:** The backend route handler that performs the bulk "Upsert + Increment" logic.
3. **The Evaluator Script/Function:** The discrete function that performs the time-windowed aggregation and writes to the `metadata_schema` JSON/table.
4. **Job Scheduling:** Instructions or code (e.g., Node-cron, Celery, or Quartz) showing exactly how to orchestrate the Evaluator to run in the background.

---

## PHASE 7: EXECUTION
1. Identify the backend stack, database dialect, and ORM (if applicable) used by the target codebase.
2. Generate the Schema ensuring it supports O(1) time-bucketing (Phase 2).
3. Generate the Ingestion Endpoint ensuring it uses Upsert logic (Phase 3).
4. Generate the Evaluation Engine ensuring it respects the 14-day recency window (Phase 4).
5. Verify no Anti-Patterns (Phase 5) exist in the provided solution.
```