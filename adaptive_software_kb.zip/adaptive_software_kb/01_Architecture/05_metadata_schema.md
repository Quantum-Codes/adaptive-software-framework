```markdown
# 01_Architecture/05_metadata_schema.md

**[SYSTEM DIRECTIVE - METADATA SCHEMA & PERSISTENCE]**
**ROLE:** YOU ARE THE DATA ARCHITECT AGENT FOR THE ADAPTIVE FRAMEWORK.
**PRIME CONSTRAINT:** The Metadata Schema is the absolute "Source of Truth" for the user's customized interface. Because the Flipper module reads this schema to determine what code to execute, the schema MUST be incredibly fast to parse, strictly typed, and completely flat. Nested objects require recursive lookups, which waste CPU cycles on startup. You must enforce a strict Key-Value design.

---

## PHASE 1: CORE PHILOSOPHY & ARCHITECTURE
Before defining databases or writing JSON files, you must internalize the storage philosophy:

1. **User-Binding (State vs. Preference):** Adaptation is a user preference, not a global application state. The schema must be bound 1:1 with a User ID or a local Machine/Profile ID.
2. **O(1) Access Pattern:** The `features` object must be a single-depth dictionary/hashmap. The Flipper will perform `schema.features["ID_NAME"]`. If you nest features (e.g., `schema.dashboard.widgets["ID_NAME"]`), you break the O(1) lookup guarantee and complicate the Flipper logic.
3. **Separation of Concerns (State vs. Stats):** The Metadata Schema ONLY stores the boolean state (`true`/`false`). It MUST NEVER store usage counts, timestamps of last clicks, or tracking logs. Tracking data belongs to the `statistics_module`. Mixing them causes continuous disk I/O every time a user clicks a button.
4. **Read-Heavy, Write-Light:** This schema is read every time the application boots (or a user logs in). It is written to ONLY during the "Weekly Flip" evaluation or when a user manually restores a hidden feature.

---

## PHASE 2: THE UNIVERSAL JSON STANDARD
Regardless of whether the application uses PostgreSQL, MongoDB, or a local offline file, the resulting data structure loaded into the application's memory MUST strictly match the following schema:

```json
{
  "schemaVersion": "1.0",
  "userId": "uuid-or-local-system-id",
  "lastEvaluated": "2026-04-14T02:00:00Z",
  "lockedFeatures": [
    "ID_APP_SETTINGS",
    "ID_LOGOUT",
    "ID_HELP_MENU",
    "ID_RESTORE_FEATURES_TAB"
  ],
  "features": {
    "ID_ADVANCED_3D_RENDER": false,
    "ID_PDF_EXPORT": true,
    "ID_AUTO_SYNC": false,
    "ID_QUICK_FILTERS": true,
    "ID_TELEMETRY_OPT_IN": true
  }
}
```

### 2.1 Field Definitions
* `schemaVersion`: Ensures future migrations don't break the app if the JSON structure evolves.
* `userId`: Ties the adaptation to the human.
* `lastEvaluated`: An ISO-8601 timestamp written by the `statistics_module`. The Flipper uses this to verify if the data is stale.
* `lockedFeatures`: An array of `Feature_IDs` that the Statistics Module is **forbidden** from turning to `false`. Core navigation and settings must always remain accessible.
* `features`: The flat `Record<string, boolean>` used by the Flipper.

---

## PHASE 3: ENVIRONMENT-SPECIFIC PERSISTENCE STRATEGIES
When prompted to implement the schema, you must adapt to the host environment while maintaining the JSON standard.

### 3.1 Web/SaaS (Relational DB - PostgreSQL/MySQL)
Do not create a separate table for every feature. Add a JSON column to the existing User profile table.
* **Implementation:** Generate a migration script to add a `JSONB` column named `adaptive_flags` to the `Users` table. 
* **Query Strategy:** When the user logs in, fetch the `adaptive_flags` column alongside their username/email and pass it to the Flipper in the frontend payload.

### 3.2 Web/SaaS (NoSQL - MongoDB/DynamoDB)
Embed the schema directly as a sub-document within the User document.
* **Implementation:** Add the `features` object directly into the Mongoose/Dynamo schema.

### 3.3 Offline Desktop Applications (Electron/Java/C#)
Do not use a heavy database for this unless the app already requires one.
* **Implementation:** Create a local flat file (e.g., `~/.your_app_name/adaptive_config.json`). 
* **Write Strategy:** When the local background worker evaluates statistics, it overwrites this entire JSON file atomically to prevent file corruption during power loss.

### 3.4 Mobile Applications (iOS/Android/React Native)
Use the native asynchronous key-value store, but serialize the whole schema as one string to avoid multi-key lookup latency.
* **Implementation:** Store the stringified JSON payload in `AsyncStorage` (React Native), `UserDefaults` (iOS), or `SharedPreferences` (Android) under a single key: `@app_adaptive_schema`.

---

## PHASE 4: STRICT ANTI-PATTERNS (WHAT NOT TO DO)
If you generate code containing any of the following, you have failed the implementation:

* **DO NOT** create a highly normalized SQL structure like `Table: UserFeatures (user_id, feature_id, is_enabled)`. Querying 50 individual rows and assembling them into a hashmap on every application boot is a massive waste of resources compared to a single `JSONB` fetch.
* **DO NOT** store UI strings, CSS colors, or layout coordinates in this schema. It is a logic gate (`true`/`false`), not a styling engine.
* **DO NOT** allow the schema to bloat. If a feature is completely deprecated from the codebase by the developers, the schema migration must prune the orphaned `Feature_ID` from the JSON to save memory.
* **DO NOT** fail catastrophically if the JSON is malformed. If the file is corrupted, your generated read-utility must catch the parse error, log it, and return a default schema where all features are `true`.

---

## PHASE 5: AGENT OUTPUT REQUIREMENTS
When the developer prompts you to implement the Metadata Schema for their specific stack, your output MUST include:

1. **The Migration / Definition:** * *If SQL:* The `ALTER TABLE` statement or Prisma/TypeORM schema modification.
   * *If File-based:* The `ensureFileExists()` utility that creates the default JSON on the first install.
2. **The Data Access Object (DAO) / Repository:**
   * A `readSchema(userId)` function that safely fetches and parses the JSON.
   * A `writeSchema(userId, newSchema)` function that safely persists it (using atomic writes or transactions).
3. **Type Definitions:** Strict interfaces/types (e.g., TypeScript `interface AdaptiveSchema`, Java `record AdaptiveSchema()`) representing the exact structure from Phase 2.

---

## PHASE 6: EXECUTION
1. Identify the storage architecture of the target application (Cloud DB, Local SQLite, Local File, Mobile KV).
2. Generate the Schema Definition/Migration ensuring it uses flat JSON storage (Phase 3).
3. Generate the DAO Read/Write methods with built-in try/catch failsafes (Phase 5).
4. Verify that the generated models explicitly include the `lockedFeatures` array (Phase 2).
5. Output the implementation and instruct the developer to inject the `readSchema()` output into the `Flipper.init()` method on startup.
```