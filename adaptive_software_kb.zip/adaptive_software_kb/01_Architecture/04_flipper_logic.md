```markdown
# 01_Architecture/04_flipper_logic.md

**[SYSTEM DIRECTIVE - FLIPPER LOGIC IMPLEMENTATION]**
**ROLE:** YOU ARE THE IMPLEMENTATION AGENT FOR THE FLIPPER MODULE (THE GLOBAL GATEKEEPER).
**PRIME CONSTRAINT:** The Flipper Module will be the most frequently invoked utility in the entire application. It might be checked hundreds of times per second during UI rendering or data processing. Therefore, the `isActive()` method MUST be 100% synchronous, execute in O(1) time, and have absolute zero I/O overhead. It must never block the main thread.

---

## PHASE 1: CORE PHILOSOPHY & ARCHITECTURE
Before generating any code, you must internalize the architectural rules of the Flipper:

1. **The "Read-Once" Rule:** The configuration (the `metadata_schema` JSON/Dictionary) is loaded from the disk, database, or network exactly **once** during the application's bootstrapping phase. It is then cached in memory.
2. **Synchronous Resolution:** Because UI layout engines (like React render cycles or JavaFX layouts) cannot easily await asynchronous configuration checks without causing screen flicker, the Flipper's query method must resolve instantly using the in-memory cache.
3. **The Failsafe Principle (Graceful Degradation):** If the configuration file is corrupted, missing, or if a developer checks a `Feature_ID` that hasn't been registered yet, the application MUST NOT crash. The Flipper must log a warning and default to `true` (Enabled). It is better to show an unoptimized feature than to break the application.
4. **Immutability During Execution:** To prevent unpredictable UI shifts, the Flipper state should ideally remain static during a user's active session. Updates from the Statistics module should be applied on the *next* application launch or page refresh, not injected live while the user is clicking.

---

## PHASE 2: INITIALIZATION & STATE MANAGEMENT
When generating the Flipper core, you must design a system that handles the initial load before the rest of the application boots.

### 2.1 The Singleton / Global Store
* **TypeScript/JavaScript (Node/React/Vue):** Implement as an ES6 Module Singleton or a Global Context Provider.
* **Java/C# (Desktop/Backend):** Implement as a static class or a Singleton instance injected via Dependency Injection (e.g., Spring or .NET Core DI).

### 2.2 The Bootstrapping Phase
Provide instructions on how the host application must pause initialization until the Flipper is loaded.
* *Example Flow:* App Starts -> Show Splash Screen -> Flipper calls `loadConfig()` from local DB -> Flipper is Ready -> App Mounts UI.

---

## PHASE 3: THE API SURFACE
The generated Flipper utility must expose a strict, minimalist API. 

### Mandatory Methods:
1. `init(configData)`: Takes the JSON payload and populates the internal cache map.
2. `isActive(featureId: string): boolean`: The primary gatekeeper method. Performs an O(1) lookup in the cache.
3. `getAllFlags(): Map<string, boolean>`: Returns a read-only snapshot of the current state (useful for sending context to crash reporters like Sentry, or for rendering the "Hidden Features" restore menu).
4. `overrideFlag(featureId: string, state: boolean)`: A local runtime override, used *only* when a user manually restores a hidden feature from the UI, updating the local cache immediately without waiting for a reboot.

### Conceptual Implementation (Language Agnostic):
```typescript
class FlipperEngine {
    private cache: Record<string, boolean> = {};
    private isInitialized: boolean = false;

    public init(configData: Record<string, boolean>): void {
        this.cache = configData;
        this.isInitialized = true;
    }

    public isActive(featureId: string): boolean {
        if (!this.isInitialized) {
            console.warn("Flipper accessed before init! Defaulting to TRUE.");
            return true;
        }
        if (this.cache[featureId] === undefined) {
            console.warn(`Unregistered FeatureID checked: ${featureId}. Defaulting to TRUE.`);
            return true;
        }
        return this.cache[featureId];
    }
}
export const Flipper = new FlipperEngine();
```

---

## PHASE 4: STRICT ANTI-PATTERNS (WHAT NOT TO DO)
If you generate code containing any of the following, you have failed the implementation:

* **DO NOT** make `isActive()` an asynchronous function (e.g., `async isActive()`, `return new Promise()`). If you do this, you will force developers to write `await Flipper.isActive()` everywhere, which fundamentally breaks synchronous UI rendering loops and constructor initializations.
* **DO NOT** perform File I/O (`fs.readFileSync`), Database Queries (`SELECT * FROM flags`), or Network Requests (`fetch()`) inside the `isActive()` method. 
* **DO NOT** throw Exceptions or Panics if a feature ID is missing. Catch the missing key, log a console warning for the developer, and return `true`.
* **DO NOT** couple the Flipper logic to the Tracking Monitor. The Flipper does not track clicks. It only answers the question: "Should this run?"

---

## PHASE 5: FRAMEWORK-SPECIFIC ADAPTERS
Because the Flipper must be easy for developers to use, you must generate framework-specific wrappers alongside the core logic.

* **For React Environments:** Generate a Custom Hook (`useFlipper`) that ties into a React Context. 
  * *Code Requirement:* `const isEnabled = useFlipper('ID_3D_RENDER');`
* **For Vue Environments:** Generate a Vue Plugin or Composition API composable (`useFlipper`).
* **For Backend APIs (Express/FastAPI/Spring):** Generate a Middleware wrapper or Annotation/Decorator that can gate an entire route.
  * *Code Requirement (Python/FastAPI):* `@require_feature("ID_REPORT_EXPORT")`
  * *Code Requirement (Node/Express):* `app.get('/report', flipperGuard('ID_REPORT_EXPORT'), controller);`

---

## PHASE 6: AGENT OUTPUT REQUIREMENTS
When the user prompts you to implement the Flipper logic, your output MUST include:

1. **The Core Singleton:** The robust, memory-safe class/object holding the cache and the `isActive` method.
2. **The Initialization Routine:** Explicit code showing how to read the `metadata_schema` and inject it into the `Flipper.init()` method before the app mounts.
3. **The Helper Wrappers:** The React Hook, Vue Composable, or Backend Middleware specific to the user's stack.
4. **Failsafe Verification:** Ensure your code explicitly demonstrates the `true` default behavior for missing keys.

---

## PHASE 7: EXECUTION
1. Identify the programming language and primary framework of the target codebase.
2. Generate the Core Singleton (Phase 3).
3. Generate the Bootstrapping logic showing where `init()` should be called (Phase 2).
4. Generate the Framework-specific adapters (Phase 5).
5. Verify absolutely no I/O operations occur inside the `isActive` lookup (Phase 4).
```