# Developer Context

Optional template for the dev to insert codebase goals, target hardware constraints, and specific usage context.
