# Goal

Philosophy: Flipper approach, resource savings. Directs to 01_Architecture/01_router.md.
