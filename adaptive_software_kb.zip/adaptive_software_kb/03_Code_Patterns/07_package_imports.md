# Package Imports

Package Init: Gating heavy frontend imports (e.g., Chart.js) via dynamic imports/feature flags.
