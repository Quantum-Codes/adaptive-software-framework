---
title: 06_db_query_logic.md

---

# 06 — DB Query Logic: Feature-Gated Query Fragmentation

**Directive:** A disabled feature must produce zero database load.
Gate the query, not the display of results. If your Flipper check
lives in the view or template layer, it is in the wrong place.
Move it into the query-building layer.

---

## Rule 1 — Fragment the Query at Build Time

Compose queries conditionally. The query sent to the database must
be structurally different when a feature is off — not the same query
with results filtered afterward.

**SQL / relational databases:**
```python
def get_users():
    cols  = ["u.id", "u.name", "u.email"]
    joins = []

    if Flipper.is_active("ID_AVATARS"):
        cols.append("p.url AS avatar_url")
        joins.append("LEFT JOIN profile_pictures p ON p.user_id = u.id")

    if Flipper.is_active("ID_USER_TAGS"):
        cols.append("GROUP_CONCAT(t.name) AS tags")
        joins.append("LEFT JOIN user_tags ut ON ut.user_id = u.id")
        joins.append("LEFT JOIN tags t ON t.id = ut.tag_id")

    return db.execute(f"""
        SELECT {', '.join(cols)}
        FROM   users u {' '.join(joins)}
        GROUP  BY u.id
    """)
```

**ORM (Django):**
```python
def get_user_queryset():
    qs = User.objects.only('id', 'name', 'email')
    if Flipper.is_active('ID_AVATARS'):
        qs = qs.select_related('profile_picture')
    if Flipper.is_active('ID_USER_TAGS'):
        qs = qs.prefetch_related('tags')
    return qs
```

**ORM (SQLAlchemy):**
```python
def build_user_query():
    q = select(User.id, User.name, User.email)
    if Flipper.is_active('ID_AVATARS'):
        q = q.outerjoin(ProfilePicture)\
             .add_columns(ProfilePicture.url.label('avatar_url'))
    return q
```

**NoSQL / document store (MongoDB):**
```javascript
function buildUserProjection() {
  const projection = { name: 1, email: 1 };

  if (Flipper.isActive('ID_AVATARS')) {
    projection.avatarUrl = 1;
  }
  if (Flipper.isActive('ID_ACTIVITY_LOG')) {
    projection.recentEvents = 1;   // only if stored on the document
  }
  return projection;
}

// For aggregations — skip the entire pipeline stage
function buildUserPipeline(userId) {
  const pipeline = [{ $match: { _id: userId } }];

  if (Flipper.isActive('ID_GEO_HEATMAP')) {
    pipeline.push({ $lookup: {
      from: 'geo_events', localField: '_id',
      foreignField: 'userId', as: 'geoEvents'
    }});
  }
  return pipeline;
}
```

---

## Rule 2 — Gate Column Selection for Wide Tables

Heavy columns (JSON blobs, BLOBs, long text) must be explicitly
excluded from SELECT when their feature is off. Same row count,
dramatically smaller result set.

```python
def get_events(limit=100):
    cols = ["id", "event_type", "user_id", "created_at"]

    if Flipper.is_active("ID_RAW_EXPORT"):
        cols.append("payload")          # large JSON blob

    if Flipper.is_active("ID_GEO_HEATMAP"):
        cols += ["latitude", "longitude", "country_code"]

    return db.execute(
        f"SELECT {', '.join(cols)} FROM events ORDER BY created_at DESC LIMIT :n",
        {"n": limit}
    )
```

---

## Rule 3 — Gate Write Operations

A disabled feature must not write its data. Stale rows for a
permanently disabled feature accumulate indefinitely and are
never read.

```python
def record_geo_event(user_id, lat, lon, country):
    if not Flipper.is_active('ID_GEO_HEATMAP'):
        return          # no insert, no disk write
    db.execute(
        "INSERT INTO geo_events (user_id, latitude, longitude, country_code) "
        "VALUES (:uid, :lat, :lon, :cc)",
        {"uid": user_id, "lat": lat, "lon": lon, "cc": country}
    )
```

Apply the same to cache write-through paths:
```javascript
async function cacheUserAvatar(userId, avatarUrl) {
  if (!Flipper.isActive('ID_AVATARS')) return;
  await redis.set(`avatar:${userId}`, avatarUrl, 'EX', 3600);
}
```

---

## Rule 4 — Gate Cache Reads

If a feature writes to a cache conditionally, its cache read must
also be gated. Do not read a cache key for a feature that is off —
the key may contain stale data from a prior active session.

```javascript
async function getUserAvatar(userId) {
  if (!Flipper.isActive('ID_AVATARS')) return null;
  return await redis.get(`avatar:${userId}`);
}
```

---

## Rule 5 — Use the `@requires_feature` Guard for Fully Optional Queries

When an entire repository function exists only for one feature,
use a decorator/wrapper to make the dependency explicit and
eliminate boilerplate guards inside every function body.

**Python:**
```python
from functools import wraps

def requires_feature(feature_id):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not Flipper.is_active(feature_id):
                return None
            return fn(*args, **kwargs)
        return wrapper
    return decorator

@requires_feature('ID_GEO_HEATMAP')
def get_geo_events(since_days=30):
    return db.execute(
        "SELECT latitude, longitude FROM geo_events "
        "WHERE created_at > NOW() - INTERVAL ':d days'",
        {"d": since_days}
    )
```

**TypeScript:**
```typescript
function requiresFeature(featureId: string) {
  return function (
    _target: object,
    _key: string,
    descriptor: PropertyDescriptor
  ) {
    const original = descriptor.value;
    descriptor.value = async function (...args: unknown[]) {
      if (!Flipper.isActive(featureId)) return null;
      return original.apply(this, args);
    };
    return descriptor;
  };
}

class AnalyticsRepo {
  @requiresFeature('ID_GEO_HEATMAP')
  async getGeoEvents(sinceDays: number) {
    return db.query(
      'SELECT latitude, longitude FROM geo_events WHERE created_at > NOW() - $1::interval',
      [`${sinceDays} days`]
    );
  }
}
```

---

## Checklist — Run Before Marking a Feature Complete

- [ ] All JOINs, subqueries, and aggregations for this feature are inside `Flipper.is_active()` blocks
- [ ] Heavy columns (BLOBs, JSON) are in a conditional `cols` list, not in every SELECT
- [ ] Write operations for feature-specific tables check the flag before executing
- [ ] Cache writes for this feature are gated
- [ ] Cache reads for this feature are gated
- [ ] Fully optional repository functions use `@requires_feature` decorator
- [ ] No gating logic lives in the view or template layer