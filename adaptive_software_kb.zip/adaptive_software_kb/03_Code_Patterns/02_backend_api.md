# Backend API Gating Pattern (Feature-Flag Controlled Execution)

## Purpose
Define a strict, production-grade pattern for implementing Feature Flag (Flipper) based gating in backend APIs.

This ensures:
- Zero execution cost for disabled features
- Minimal database load
- No unnecessary memory or CPU usage
- Deterministic and safe behavior

This pattern is mandatory for all feature-dependent backend logic.

---

## Core Principle

All feature-dependent logic MUST be gated using:

Flipper.isActive(Feature_ID)

No heavy computation, database query, external API call, or import should execute before this check.

---

## Feature Identification Requirement

Before applying this pattern:
- Every feature MUST have a unique Feature_ID
- Feature_ID must be consistent across:
  - frontend
  - backend
  - statistics module

Example:
ID_ANALYTICS  
ID_EXPORT_PDF  
ID_PROFILE_PIC  

---

## Pattern 1: Route-Level Gating

### Use Case
The entire API route belongs to a feature.

### Implementation

```js
app.get("/export/pdf", async (req, res) => {
    if (!Flipper.isActive("ID_EXPORT_PDF")) {
        return res.status(403).json({ error: "Feature disabled" });
    }

    const result = await generatePDF(req.body);
    return res.json(result);
});
```
### Outcome

- Prevent execution completely
- Saves CPU,memory and I/O 

## Pattern 2: Inline Logic Gating

### Use Case
Only part of the API is expensive or optional 

```js
app.get("/dashboard", async (req, res) => {
    const basicData = await getBasicData();

    let analytics = null;

    if (Flipper.isActive("ID_ANALYTICS")) {
        analytics = await computeAnalytics();  // heavy
    }

    return res.json({ basicData, analytics });
});
```
### Outcome

- Base functionality remains intact 
- Expensive logic is skipped when disabled

## Pattern 3: Database Query Fragmentation 

### Problem
Large queries and joins waste resources if data is unused

if any confusion  NAVIGATE to "06_db_query_logic.md"
### Solution 
Split queries based on the Feature_ID for example 
```js 
let user;

if (Flipper.isActive("ID_PROFILE_PIC")) {
    user = await db.query(`
        SELECT u.*, p.image
        FROM users u
        LEFT JOIN profile_pics p ON u.id = p.user_id
    `);
} else {
    user = await db.query(`
        SELECT u.*
        FROM users u
    `);
}
```
#### Outcome
- Avoids unnecessary joins
- Reduces database load

## Pattern 4: Lazy import of heavy dependencies

### Problem
Heavy libraries consume memory even when unused

### Solution 
Import only inside the feature gate 
```js
if (Flipper.isActive("ID_REPORTS")) {
    const reportEngine = await import("heavy-report-lib");
    await reportEngine.generate();
}
```
###  Rules
- NEVER import heavy modules at top Level   
- Always gate before import 

## Pattern 5: External API/ Service Call Gating

### Problem
Unnecessary external calls increase the latency and cost. 
```js
if (Flipper.isActive("ID_THIRD_PARTY_SYNC")) {
    await syncWithExternalService();
}
```
## Pattern 6: Response Shaping (Selective Data Return)

### Problem
Returning unused data increases the payload size and compute cost 

```js 
const response = {
    name: user.name,
};

if (Flipper.isActive("ID_ADVANCED_PROFILE")) {
    response.details = await getAdvancedDetails();
}

return res.json(response);
```
## Pattern 7: Early Exit Optimization

### Purpose
Terminate execution as early as possible

```js 
if (!Flipper.isActive("ID_HEAVY_FEATURE")) {
    return res.json({ message: "Feature disabled" });
}
```
### Outcome

- Prevent unnecessary execution path traversal 

## Anti Patterns (STRICTLY FORBIDDEN)
 
 - Running heavy logic before checking Feature_ID
 - Importing heavy libraries globally
 - Writing monolithic database queries ignoring feature usage
 - Triggering background jobs inside APIs without Gating
 - Ignoring Feature_ID consistency across system

## Performance Guarantees
 When Implemented correctly:
 - Disabled features consume zero CPU and RAM 
 - Database load is minimized
 - API latency improves
 - System scales better on low-end hardware

 ## Integration Requirements
 
 The pattern MUST be used with 
 - Flipper module (config based booleann gating)
 - Statistics module (for feature usage tracking)
 - Feature tagging system 


 ## Final Rules
 If a backend operation is associated with a Feature_ID, it MUST be gated using Flipper before execution 
 No EXCEPTIONS.