---
title: 05_asset_manager.md

---

# 05 — Asset Manager: Conditional Asset Loading

**Directive:** Gate every asset load behind its Feature ID.
An asset that belongs to a disabled feature must consume zero
memory, zero network bandwidth, and zero decode cycles.
Fetching and hiding is a failure. Not fetching is the goal.

---

## Rule 1 — Establish an Asset Manifest First

Before writing any loading code, register all feature-owned assets
in a central manifest. This is your single source of truth.Do not infer types at runtime.

```json
// asset_manifest.json
{
  "ID_3D_VIEWER":          [{"path": "models/product.glb", "type": "model"}, {"path": "models/env.hdr", "type": "image"}],
  "ID_ADVANCED_DASHBOARD": [{"path": "img/hero-banner.webp", "type": "image"}, {"path": "fonts/dash.woff2", "type": "font"}],
  "ID_PDF_EXPORT":         [{"path": "templates/invoice.pdf", "type": "document"}],
  "ID_AUDIO_FEEDBACK":     [{"path": "audio/confirm.wav", "type": "audio"}, {"path": "audio/error.wav", "type": "audio"}]
}
```

**Instructor note to agent:** If a file path does not appear in this
manifest, it is an always-on asset and requires no gating. If it does
appear, every load path for that asset must go through the check below.

---

## Rule 2 — The Universal Load Guard

Regardless of platform or asset type, every loader must follow this
structure. Adapt the syntax; never skip the guard.

```
IF Flipper.isActive(featureId) is FALSE → return immediately, load nothing
IF Flipper.isActive(featureId) is TRUE  → proceed with load
```

**Web (JS):**
```javascript
async function loadFeatureAssets(featureId) {
  if (!Flipper.isActive(featureId)) return;
  const paths = assetManifest[featureId] ?? [];
  for (const path of paths) {
    injectPreloadHint(path);      // see Rule 4
  }
}
```

**Mobile native (Swift / Kotlin):**
```swift
func loadFeatureAsset(featureId: String, resourceName: String) -> UIImage? {
    guard Flipper.isActive(featureId) else { return nil }
    return UIImage(named: resourceName)
}
```

**Desktop (Python / Electron / Tauri):**
```python
def load_asset(feature_id: str, path: str) -> bytes | None:
    if not Flipper.is_active(feature_id):
        return None
    with open(path, 'rb') as f:
        return f.read()
```

**Game engine (Unity C#):**
```csharp
IEnumerator LoadFeatureBundle(string featureId, string bundlePath) {
    if (!Flipper.IsActive(featureId)) yield break;
    var request = AssetBundle.LoadFromFileAsync(bundlePath);
    yield return request;
    // use request.assetBundle
}
```

---

## Rule 3 — Web DOM: Never Put a Src Before the Guard

Two patterns that bypass Rule 2 and must be corrected on sight:

**Pattern to eliminate — hardcoded `src`:**
```html
<!-- WRONG: browser fetches this at parse time, flag is never checked -->
<img src="/assets/3d-viewer/hero.png" />
```
```html
<!-- CORRECT: src is absent; JS assigns it only after flag check -->
<img data-feature="ID_3D_VIEWER" data-src="/assets/3d-viewer/hero.png" />
```

**Pattern to eliminate — CSS `url()` and `@font-face` on unconditional selectors:**
```css
/* WRONG: browser fetches this asset even if .dashboard-hero is display:none */
.dashboard-hero { background-image: url('/assets/hero.webp'); }
```
```javascript
// CORRECT: add feature class to <html> only when flag is active.
// CSS selectors that depend on this class are never matched otherwise.
if (Flipper.isActive('ID_ADVANCED_DASHBOARD')) {
  document.documentElement.classList.add('feat--advanced-dashboard');
}
```
```css
.feat--advanced-dashboard .dashboard-hero {
  background-image: url('/assets/hero.webp');
}
```

---

## Rule 4 — Inject Preload Hints Programmatically, Never in HTML

`<link rel="preload">` in static HTML fires unconditionally.
Always inject it from JS after the flag check.

```javascript
function injectPreloadHint(url) {
  const link  = document.createElement('link');
  link.rel    = 'preload';
  link.href   = url;
  link.as     = detectType(url);   // 'image' | 'font' | 'fetch'
  document.head.appendChild(link);
}

function detectType(url) {
  if (/\.(png|jpg|webp|svg|avif)$/i.test(url)) return 'image';
  if (/\.(woff2?|ttf|otf)$/i.test(url))        return 'font';
  return 'fetch';
}
```

---

## Rule 5 — Shared Assets

If an asset is needed by both a gated feature and an always-on path,
the asset is **not** feature-owned. Remove it from the manifest.
Do not duplicate load logic for it. Load it unconditionally in your
standard asset initialization.

```
Asset used by ID_AVATARS AND by the always-on profile page?
→ Remove from manifest. Load unconditionally. No flag check.

Asset used ONLY by ID_AVATARS?
→ Keep in manifest. Guard with Flipper.isActive('ID_AVATARS').
```

---

## Rule 6 — Server-Side Asset Routes

If your backend serves assets over HTTP, gate the route itself.
Do not serve a 200 response for a disabled feature's asset.

```javascript
// Express.js
app.get('/assets/3d-viewer/:file', (req, res) => {
  if (!Flipper.isActive('ID_3D_VIEWER')) {
    return res.status(404).end();
  }
  res.sendFile(path.join(assetDir, req.params.file));
});
```

This prevents clients from bypassing client-side guards by
requesting the asset URL directly.

---

## Checklist — Run Before Marking a Feature Complete

- [ ] All asset paths are in `asset_manifest.json`
- [ ] No `<img src>`, `<link rel="preload">`, or CSS `url()` references are hardcoded for this feature
- [ ] Every platform-specific loader begins with `Flipper.isActive()` guard
- [ ] Shared assets are confirmed and removed from the manifest
- [ ] Server route for feature assets returns 404 when flag is off