# Frontend DOM

Basic visibility toggling for UI components.
