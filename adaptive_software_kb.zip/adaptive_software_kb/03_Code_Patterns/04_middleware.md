# Middleware Gating Pattern (Request-Level Feature Control)

## Purpose
Define a strict, production-grade pattern for using middleware to enforce Feature Flags (Flipper) at the request level.

This ensures:
- Centralized feature enforcement
- Zero execution of disabled routes/features
- Clean separation of concerns
- Minimal repeated checks inside business logic

This pattern is mandatory for all feature-controlled routes and cross-cutting concerns.

---

## Core Principle

Middleware acts as a **central enforcement layer** for Feature_ID checks.

All route-level access control MUST be handled before reaching business logic.

---

## Feature Identification Requirement

Every protected route or middleware-controlled feature MUST have a Feature_ID.

Examples:
ID_PREMIUM  
ID_ADMIN_PANEL  
ID_ANALYTICS  
ID_EXPORT  

---

## Pattern 1: Route-Level Access Control Middleware

### Use Case
Entire route belongs to a feature.

### Implementation

```js
function requireFeature(featureId) {
    return (req, res, next) => {
        if (!Flipper.isActive(featureId)) {
            return res.status(403).json({ error: "Feature disabled" });
        }
        next();
    };
}
```
### Usage 
```js 
app.get("/premium/dashboard", requireFeature("ID_PREMIUM"), handler);
```

### Outcome 
- Blocks request early 
- Prevents unnecessary processing 

## Pattern 2: Global Feature Injection 

### Purpose 
Avoid repeated Flipper calls across handlers.

### Implementation 
```js 
app.use((req, res, next) => {
    req.features = Flipper.getAll();
    next();
});
```

### Usage 
```js
 if (req.features.ID_ANALYTICS) {
    computeAnalytics();
}
```

### Outcome 
- Reduces redundant Flipper lookups 
- Cleaner handler code 

## Pattern 3: Optional Feature Middleware (Conditional Execution )

### Use Case 
Middleware should run only if feature is enabled.

```js 
function optionalFeature(featureId, middleware) {
    return (req, res, next) => {
        if (!Flipper.isActive(featureId)) return next();
        return middleware(req, res, next);
    };
}
```
For example : 
```js 
app.use(optionalFeature("ID_LOGGING", requestLogger));
``` 

### Outcome 
- Middleware remains lightweight
- No unnecessary execution 

## Pattern 4: Feature-Based Routing Control 

### Use Case
Enable or Disable entire route groups.

```js 
if (Flipper.isActive("ID_ADMIN_PANEL")) {
    app.use("/admin", adminRoutes);
}
```
### Outcome 
- Routes never registered if disabled 
- Zero runtime overhead 

## Pattern 5: Response Header Injection(Optional)

### Purpose 
Expose feature flags to frontend or clients.
```js 
app.use((req, res, next) => {
    res.setHeader("X-Feature-Flags", JSON.stringify(Flipper.getAll()));
    next();
});
```
### Outcome
- Enables frontend adaption 
- Maintains sync with backend flags 

## Pattern 6: Feature Usage Tracking Middleware 
### Purpose 
Integrate with Statistics module.

```js 
function trackFeature(featureId) {
    return (req, res, next) => {
        Stats.increment(featureId);
        next();
    };
}
```
### Usage 
```js 
app.get("/analytics", trackFeature("ID_ANALYTICS"), handler);
```

## Pattern 7: Early Termination Middleware 
### Purpose 
Stop requests as early as possible 
```js 
function blockIfDisabled(featureId) {
    return (req, res, next) => {
        if (!Flipper.isActive(featureId)) {
            return res.status(404).json({ error: "Not available" });
        }
        next();
    };
}
```

### Outcome 
- Reduces processing overhead 
- Avoids reaching deeper layers 

## Anti-Patterns(STRICTLY FORBIDDEN)
- Performing heavy computation inside middleware
- Rechecking Feature_ID repeatedly in deep logic
- Mixing business logic inside middleware
- Registering all routes regardless of feature state
- Using middleware without Feature_ID mapping
## Performance Guarantees

When implemented correctly:

- Requests for disabled features terminate instantly
- Reduced CPU usage per request
- Cleaner and maintainable routing layer
- Improved scalability
## Integration Requirements

This pattern MUST integrate with:

- Flipper module (feature state provider)
- Statistics module (optional tracking)
- Backend API gating patterns
## Final Rule

Middleware should:

- Enforce access
- Inject feature state
- Remain lightweight

All feature-based decisions MUST occur before business logic execution.

No EXCEPTIONS.